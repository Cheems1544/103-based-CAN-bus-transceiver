#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "CAN.h"

int main(void) 
{
  CAN_Configuration();
	OLED_Init();
	OLED_ShowString(1, 1, "TxPacket:");
	OLED_ShowString(3, 1, "RxPacket:");
 
  while (1)
	{
	// 发送CAN消息
  CAN_SendMessage(0xAA);
	OLED_ShowString(2, 1, "                ");
	OLED_ShowString(2, 1, "CAN_SendMessage");
  // 接收CAN消息
  CAN_ReceiveMessage();
	OLED_ShowString(4, 1, "                ");
	OLED_ShowString(4, 1, "CAN_SendMessage");
  }
}
